(function () {
    'use strict';

    angular
            .module('myApp.subfeatureService', [])
            .factory('subfeatureService', subfeatureService);

    subfeatureService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout', '$localStorage', '$sessionStorage','configData'];
    function subfeatureService($http, $cookieStore, $rootScope, $timeout, $localStorage, $sessionStorage,configData) {
        var service = {};
        service.getAllSubFeature = getAllSubFeature;
        service.saveSubFeature = saveSubFeature;
        service.updateSubFeature = updateSubFeature;
        return service;


        function getAllSubFeature(config) {
            return $http.get(configData.url+'subfeature/list',config).then(handleSuccess, handleError('Error getting subfeature list'));
        }
        function saveSubFeature(data) {
         return $http.post(configData.url+'subfeature', data,config).then(handleSuccess, handleError('Error saving subfeature '));
        }

        function updateSubFeature(data) {
            return $http.put(configData.url+'subfeature', data,config).then(handleSuccess, handleError('Error saving subfeature '));
        }
        function handleSuccess(res) {
        	console.log("-----service"+res);
            return res.data;
        }

        function handleError(error) {
            return function () {
                return {success: false, message: error};
            };
        }


    }
})();
