(function () {
    'use strict';

    angular
            .module('myApp.resetPasswordService', [])
            .factory('resetPasswordService', resetPasswordService);

    resetPasswordService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout', '$localStorage', '$sessionStorage','configData'];
    function resetPasswordService($http, $cookieStore, $rootScope, $timeout, $localStorage, $sessionStorage,configData) {
        var service = {};
        service.sendMobilenumber = sendMobilenumber;
        service.sendMail =sendMail;
        service.validateotp=validateotp;
        service.resetpasswordbyotp=resetpasswordbyotp;
        return service;

        function sendMobilenumber(config) {
            return $http.get(configData.url+'user/sendnotification',config).then(handleSuccess, handleError('Error sending mobile number'));
        }
        function sendMail(config) {
            return $http.get(configData.url+'user/sendnotification',config).then(handleSuccess, handleError('Error sending mail'));
        }
        function validateotp(config) {
            return $http.post(configData.url+'user/validateotp',config).then(handleSuccess, handleError('Error validating otp'));
        }
        function resetpasswordbyotp(config) {
            return $http.put(configData.url+'user/resetpassword',config).then(handleSuccess, handleError('Error in reseting password'));
        }
        function handleSuccess(res) {
        	console.log("-----service"+res);
            return res.data;
        }

        function handleError(error) {
            return function () {
                return {success: false, message: error};
            };
        }


    }
})();
