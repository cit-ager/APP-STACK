'use strict';

angular.module('myApp.subfeatureController', [])
        .controller('subfeatureController', ['$scope','$rootScope', '$http', '$interval', '$q' ,'subfeatureService','FlashService',function ($scope,$rootScope, $http, $interval, $q,categoryService,FlashService) {
$scope.businessunitList=[];
  $scope.businessunitId=null;
  var headers = {
		    'Auth_Token':$rootScope.globals.userDTO.token
		  }

	var config={
		  headers:headers
	}
  var fakeI18n = function( title ){
	    var deferred = $q.defer();
	    $interval( function() {
	      deferred.resolve( 'col: ' + title );
	    }, 1000, 1);
	    return deferred.promise;
	  };
	  $scope.gridOptions = {
	  };

            $scope.gridOptions = {
              paginationPageSizes: [25, 50, 75],
              paginationPageSize: 25,
              exporterMenuCsv: true,
              enableGridMenu: true,
              enableFiltering: true,
              gridMenuTitleFilter: fakeI18n,
              columnDefs: [
                { name: 'subFeatureName', displayName:"Business Unit Name" },
                {name:'subFeatureDesc',displayName:"Business Unit Description" },
                {name:'featureId',displayName:"Organization Id" },
                {name:'subFeatureURL',displayName:"Category Id" },
                {name:'subFeatureId',displayName:"Action",cellTemplate: '<div  class="ui-grid-cell-contents" >  <div class="col-sm-12 lookup-action"> \
                     &nbsp; <i class="fa fa-pencil-square-o" ng-click="grid.appScope.editSubFeature(COL_FIELD)" style="cursor:pointer" ></i> \
                     &nbsp; <i class="fa fa-eye" ng-click="grid.appScope.viewSubFeature(COL_FIELD)"  style="cursor:pointer"></i> \
                 </div></div> ',enableFiltering: false,width:100}
              ],

              onRegisterApi: function( gridApi ){
                $scope.gridApi = gridApi;

                // interval of zero just to allow the directive to have initialized


                gridApi.core.on.columnVisibilityChanged( $scope, function( changedColumn ){
                  $scope.columnChanged = { name: changedColumn.colDef.name, visible: changedColumn.colDef.visible };
                });
              }
            };

          /*  $http.get('http://ui-grid.info/data/100.json')
              .success(function(data) {
                $scope.gridOptions.data = data;
              });*/
      loadAll();
      function loadAll(){

       
     
        subfeatureService.getAllSubFeature(config).then(function (data) {
             $scope.subfeatureList= data;

             for(var i=0;i<$scope.subfeatureList.length;i++)
             {
                  $scope.subfeatureList[i].action="";
             }
               $scope.gridOptions.data =$scope.subfeatureList;
          });
        console.log("----------"+$scope.subfeatureList);
      }

      $scope.createBusinessUnit = function () {
       
        $scope.headername = "Create Business Unit";
        $scope.name ="";
        $scope.description="";
        $scope.featureid=null;
        $scope.subfeatureurl=null;
        
      //  $scope.category={};
      $scope.businessunitId=null;

        $rootScope.isTrascError = false;
        $scope.isView = false;
        $('div').removeClass('has-error edited').removeClass('has-error');
        $('input').removeClass('form-control edited').addClass('form-control');
        $('textarea').removeClass('form-control edited').addClass('form-control');
        $('select').removeClass('form-control edited').addClass('form-control');
        $('#subfeature-model').modal('show');
      }
      $scope.editSubFeature=function(value)
      	{
        
          $scope.isView = false;
        	$scope.headername = "Edit Business Unit";
          $scope.name ="";
          $scope.description="";
          $scope.featureid=null;
          $scope.subfeatureurl=null;
          $scope.subfeatureId=null;
        
          for(var i=0;i<$scope.subfeatureList.length;i++)
          {
              if ($scope.subfeatureList[i].subFeatureId==value)
               {

                $scope.name=$scope.subfeatureList[i].subFeatureName;
                $scope.description=$scope.subfeatureList[i].subFeatureDesc;
                $scope.featureid=$scope.subfeatureList[i].featureId;
                $scope.subfeatureurl=$scope.subfeatureList[i].subFeatureURL;

              }
          }
          $rootScope.isTrascError = false;
          $('div').removeClass('has-error edited');
          $('input').removeClass('form-control').addClass('form-control edited');
          $('textarea').removeClass('form-control').addClass('form-control edited');
          $('select').removeClass('form-control').addClass('form-control edited');
          $('#subfeature-model').modal('show');
      				}
        $scope.viewSubFeature=function(value)
                {
                  $scope.name ="";
                  $scope.description="";
                  $scope.featureid=null;
                  $scope.subfeatureurl=null;
                  $scope.subfeatureId=null;
                  $scope.headername = "View sub feature";
                  $scope.isView = true;
                  for(var i=0;i<$scope.subfeatureList.length;i++)
                  {
                      if ($scope.subfeatureList[i].businessunitId==value)
                      {
                        $scope.name=$scope.subfeatureList[i].subFeatureName;
                        $scope.description=$scope.subfeatureList[i].subFeatureDesc;
                        $scope.featureid=$scope.subfeatureList[i].featureId;
                        $scope.subfeatureurl=$scope.subfeatureList[i].subFeatureURL;


                      }
                  }
                  $rootScope.isTrascError = false;
                  $('div').removeClass('has-error edited');
                  $('input').removeClass('form-control').addClass('form-control edited');
                  $('textarea').removeClass('form-control').addClass('form-control edited');
                  $('select').removeClass('form-control').addClass('form-control edited');
                  $('#businessunit-model').modal('show');
                      }

                      $scope.saveSubFeature = function (subfeatureurl,featureid,name,description) {
                        var subfeature={};
                        var subfeatureId=$scope.subfeatureId;
                        subfeature.name = name;
                         subfeature.description = description;
                         subfeature.featureId=featureid;
                         subfeature.subFeatureURL=subfeatureurl;
                        $scope.continuesave = true;
                            if (!name || name==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter sub feature Name");
                                 $scope.continuesave = false;
                             } else if (!description || description==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter sub feature description");
                                 $scope.continuesave = false;
                             }
                             else if (!featureid || featureid==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter featureid");
                                 $scope.continuesave = false;
                             }
                             else if (!subfeatureurl || subfeatureurl==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter subfeatureurl");
                                 $scope.continuesave = false;
                             } else {
                                 $scope.continuesave = true;
                                 $rootScope.isTrascError = false;
                             }

                            if ($scope.continuesave) {

                                 if (!subfeatureId) {
                                
                                     subfeatureService
                                             .saveSubFeature(subfeature)
                                             .then(
                                                     function (result) {
                                                         if (result.httpStatus == 201) {

                                                             $('#subfeature-model').modal('hide');
                                                             loadAll();
                                                             $scope.successTextAlert = result.data.message;
                                                             $scope.showSuccessAlert = true;
                                                         } else {
                                                             $rootScope.isTrascError = true;
                                                             FlashService.Error(result.data.message);
                                                             $scope.continuesave = false;
                                                         }
                                                         $timeout(function () {
                                                             $scope.showSuccessAlert = false;
                                                         }, 5000);
                                                     });
                                 } else {
                                 
                                   subfeature.subfeatureId=subfeatureId;
                                    subfeatureService
                                             .updateSubFeature(subfeature)
                                             .then(
                                                     function (result) {
                                                         if (result.httpStatus == 200) {
                                                             $('#subfeature-model').modal('hide');
                                                             loadAll();
                                                             $scope.successTextAlert = result.data.message;
                                                             $scope.showSuccessAlert = true;
                                                         } else {
                                                             $rootScope.isTrascError = true;
                                                             FlashService.Error(result.data.message);
                                                             $scope.continuesave = false;
                                                         }
                                                         $timeout(function () {
                                                             $scope.showSuccessAlert = false;
                                                         }, 5000);
                                                     });
                                 }
                             }
                      }


            }]);
