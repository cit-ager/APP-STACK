(function () {
    'use strict';

    angular
            .module('myApp.userService', [])
            .factory('userService', userService);

    userService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout', '$localStorage', '$sessionStorage','configData'];
    function userService($http, $cookieStore, $rootScope, $timeout, $localStorage, $sessionStorage,configData) {
        var service = {};
        service.getAllUsers = getAllUsers;
        service.getAllRoles = getAllRoles;
        service.saveUser = saveUser;
        service.updateUser = updateUser;
        service.getUser = getUser;
        service.getAllOrganizations = getAllOrganizations;
        service.getAllBuisnessUnits = getAllBuisnessUnits;
        service.getAllProjecttypes =  getAllProjecttypes;
        service.getAllProjectSites = getAllProjectSites;
        service.getAllProjectPhase = getAllProjectPhase;
        service.getAllBuildingType = getAllBuildingType;
        service.getAllBuildingFloor = getAllBuildingFloor;
        service.getAllBuildingUnits = getAllBuildingUnits;
        service.getAllBuildingSubUnits = getAllBuildingSubUnits;
        service.getAllWorkPackages = getAllWorkPackages;
        service.getAllContractors = getAllContractors;
        service.getAllConsultancy = getAllConsultancy;
        service.getAllBuildingSubUnitsbyBUId = getAllBuildingSubUnitsbyBUId;
        return service;


        function getAllUsers(config) {
            return $http.get(configData.url+'user/list',config).then(handleSuccess, handleError('Error getting users'));
        }
        function getAllRoles(config) {
            return $http.get(configData.url+'role/list',config).then(handleSuccess, handleError('Error getting users'));
        }
        function getAllOrganizations(config) {
            return $http.get(configData.url+'organization/list',config).then(handleSuccess, handleError('Error getting organization list'));
        }
        function getAllBuisnessUnits(config) {
            return $http.get(configData.url+'businessunit/list',config).then(handleSuccess, handleError('Error getting businessunit list'));
        }
        function getAllProjecttypes(config) {
            return $http.get(configData.url+'projecttype/list',config).then(handleSuccess, handleError('Error getting projecttype list'));
        }
        function getAllProjectPhase(config) {
            return $http.get(configData.url+'projectphase/list',config).then(handleSuccess, handleError('Error getting projectphase list'));
        }
        function getAllProjectSites(config) {
            return $http.get(configData.url+'projectsite/list',config).then(handleSuccess, handleError('Error getting projectsite list'));
        }
        function getAllBuildingType(config) {
            return $http.get(configData.url+'buildingtype/list',config).then(handleSuccess, handleError('Error getting buildingtype list'));
        }
        function getAllBuildingFloor(config) {
            return $http.get(configData.url+'buildingfloor/list',config).then(handleSuccess, handleError('Error getting buildingfloor list'));
        }
        function getAllBuildingUnits(config) {
            return $http.get(configData.url+'buildingunit/list',config).then(handleSuccess, handleError('Error getting buildingunit list'));
        }
        function getAllBuildingSubUnits(config) {
            return $http.get(configData.url+'buildingsubunit/list',config).then(handleSuccess, handleError('Error getting buildingsubunit list'));
        }
        function getAllWorkPackages(config) {
            return $http.get(configData.url+'workpackage/list',config).then(handleSuccess, handleError('Error getting workpackage list'));
        }
        function getAllContractors(config) {
            return $http.get(configData.url+'contractor/list',config).then(handleSuccess, handleError('Error getting contractor list'));
        }
        function getAllConsultancy(config) {
            return $http.get(configData.url+'consultancy/list',config).then(handleSuccess, handleError('Error getting consultancy list'));
        }
        function getUser(id) {
            return $http.get(configData.url+'user/'+id,config).then(handleSuccess, handleError('Error getting users'));
        }

        function saveUser(data) {
         return $http.post(configData.url+'user', data,config).then(handleSuccess, handleError('Error saving users '));
        }
        function getAllBuildingSubUnitsbyBUId(config) {
            return $http.get(configData.url+'buildingsubunit/list',config).then(handleSuccess, handleError('Error getting buildingsubunit list'));
        }
        function updateUser(data) {
            return $http.put(configData.url+'user', data,config).then(handleSuccess, handleError('Error saving users '));
        }

        function handleSuccess(res) {
        	console.log("-----service"+res);
            return res.data;
        }

        function handleError(error) {
            return function () {
                return {success: false, message: error};
            };
        }


    }
})();
