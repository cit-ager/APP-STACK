(function() {
	'use strict';
	angular.module('myApp.AuthenticationService', []).factory(
			'AuthenticationService', AuthenticationService);

	AuthenticationService.$inject = [ '$http', '$cookieStore', '$rootScope',
			'$timeout', '$localStorage', '$sessionStorage', '$location',
			'$window','configData' ];
	function AuthenticationService($http, $cookieStore, $rootScope, $timeout,
			$localStorage, $sessionStorage, $location, $window,configData) {
		var service = {};
		service.Login = Login;
		service.SetToken = SetToken;
		service.ClearToken = ClearToken;
		service.Logout = Logout;
		return service;

		function Login(username, password, callback) {

			$http.post(configData.url+'user/validate-login', {
				username : username,
				password : password
			}).success(function(response) {
			
				if(response.status)
					{
					
			SetToken(response);
					}
				callback(response);
					
			}).error(function(error) {
				callback(error);

			});
		}

		function SetToken(result) {

			$rootScope.globals = {
				userDTO : {
					username : result.data.object.username,
					name : result.name,
					userId : result.data.object.userId,
					userType : result.data.object.userType,
					userMode: result.categoryType,
				//	empNumber : result.empNumber,
					token : result.data.object.token,
					organizationId:result.data.object.organizationId

					}
				};
			            for(var i=0;i<result.data.object.features.length;i++)
			            	{
			            	if(result.data.object.features[i].featureName.toUpperCase()=='MOBILE')
			            		{
			            		result.data.object.features.splice(i, 1);
			            		}
			            	}
						$localStorage.features=result.data.object.features;
						$rootScope.features=result.data.object.features;
						//$sessionStorage.features=result.features;
						$sessionStorage.logintoken =true;
						 $cookieStore.put('configJsUrl', configData.url);
                        $rootScope.isLogin=$sessionStorage.logintoken;
                        $http.defaults.headers.common['Auth_Token'] = result.token;
                        $cookieStore.put('globals', $rootScope.globals);
                  }

		function ClearToken() {
                        $rootScope.isLogin=false;
			$rootScope.globals = {};
			$cookieStore.remove('globals');
			$sessionStorage.Login = "";
			$localStorage.features = "";
			$http.defaults.headers.common['Auth_Token'] = '';
		}

		function Logout() {
			$http.get(configData.url+'/user/logout').success(
					function(response) {
						// callback(response);
						console.log('logout--')
						ClearToken();
						$location.path('/login');
						$window.location.reload(true);
					}).error(function(response) {
				// callback(response);
			});

		}
	}
})();
