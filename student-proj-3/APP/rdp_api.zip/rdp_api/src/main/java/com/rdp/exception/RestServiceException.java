package com.rdp.exception;

public class RestServiceException {

}
