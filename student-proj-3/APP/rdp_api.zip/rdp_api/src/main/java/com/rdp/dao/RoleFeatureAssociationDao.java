package com.rdp.dao;

import java.util.List;

import com.rdp.domain.RoleFeaturAssociation;
import com.rdp.exception.RDPException;

public interface RoleFeatureAssociationDao {
	
	public Integer saveRoleFeatureAssociation(RoleFeaturAssociation rfAssociation)throws RDPException;
	public Integer updateRoleFeatureAssociation(RoleFeaturAssociation rfAssociation)throws RDPException;
	
	public Integer deleteRoleFeatureAssocitation(Integer roleFeatureAssociationId)throws RDPException;
	public List<RoleFeaturAssociation> getRoleFeatureAssociationById(Integer rfAssocitationId)throws RDPException;
	public List<RoleFeaturAssociation> getRoleFeatureAssociation()throws RDPException;
	
	public int[] batchUpdate(List<Object[]> roleFeatureAssociationIds) throws RDPException ;

}
