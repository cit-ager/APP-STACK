package com.rdp.services;


import java.util.List;

import com.rdp.domain.User;
import com.rdp.exception.RDPException;



public interface UserService {

	public User validateLogin(User user) throws Exception;

	public Integer saveUser(User user, String resultPath, String realPath) throws RDPException;

	public User getUserById(Integer userId) throws RDPException;

	public List<User> getusers() throws RDPException;

	public Integer deleteUser(Integer userId) throws RDPException;


	public Integer updateUser(User user, String resultPath, String realPath) throws RDPException;
	
}
