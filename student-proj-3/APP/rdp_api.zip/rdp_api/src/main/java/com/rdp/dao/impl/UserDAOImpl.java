package com.rdp.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.rdp.dao.UserDAO;
import com.rdp.domain.Images;
import com.rdp.domain.User;
import com.rdp.exception.RDPException;


@Repository
@Transactional
public class UserDAOImpl implements UserDAO {

	@Autowired
	private Environment environment;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public Object[] validateLogin(String username, String password) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer saveuser(User user) throws RDPException {
		@SuppressWarnings("unused")
		final PreparedStatementCreator psc = new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(final Connection connection) throws SQLException {
				final PreparedStatement ps = connection.prepareStatement(environment.getProperty("INSERT_USER"),
						Statement.RETURN_GENERATED_KEYS);
				ps.setInt(1, user.getRoleId());
				ps.setString(2, user.getFullName());
				ps.setString(3, user.getUsername());
				ps.setString(4, user.getPassword());
				ps.setString(5, user.getDob());
				ps.setString(6, user.getGender());
				ps.setString(7, user.getIdentityNumber());
				ps.setString(8, user.getUserType());
				ps.setString(9, user.getPrimaryEmail());
				ps.setString(10, user.getAlternateEmail());
				ps.setString(11, user.getPrimaryMobileNo());
				ps.setString(12, user.getAlternateMobileNo());
				ps.setString(13, user.getCountry());
				ps.setString(14, user.getState());
				ps.setString(15, user.getCity());
				ps.setInt(16, user.getZipcode() != null ? user.getZipcode() : 0);
				ps.setString(17, user.getAddress());
				ps.setInt(18, user.getCreatedBy());

				return ps;
			}
		};

		// The newly generated key will be saved in this object
		final KeyHolder holder = new GeneratedKeyHolder();
		jdbcTemplate.update(psc, holder);
		return holder.getKey().intValue();
	}





	@Override
	public Integer updateuser(User user) throws RDPException {
		Integer result = 0;
		result = jdbcTemplate.update(environment.getProperty("UPDATE_USER_BY_ID"),
				new Object[] { user.getRoleId(), user.getUsername(), user.getPassword(), user.getFullName(),
						user.getDob(), user.getGender(), user.getIdentityNumber(), user.getUserType(),
						user.getPrimaryEmail(), user.getAlternateEmail(), user.getPrimaryMobileNo(),
						user.getAlternateMobileNo(), user.getCountry(), user.getState(), user.getCity(),
						user.getZipcode(), user.getAddress(), user.getUpdatedBy(), user.getUserId() });
		return result;
	}

	@Override
	public User getuserById(Integer userId) throws RDPException {
		User user = new User();
		user = jdbcTemplate
				.query(environment.getProperty("USER_SELECT_BY_ID"), new Object[] { userId }, (rs, rowNum) -> {
					User user1 = new User();
					Images images = new Images();
					List<Images> imageList = new ArrayList<>();
					user1.setUserId(rs.getInt("User_Id"));
					user1.setUsername(rs.getString("Username"));
					user1.setFullName(rs.getString("Fullname"));
					user1.setPassword(rs.getString("Password"));
					user1.setRoleId(rs.getInt("Role_Id"));
					user1.setRoleName(rs.getString("Role_Name"));
					user1.setDob(rs.getString("Dob"));
					user1.setGender(rs.getString("Gender"));
					user1.setUserType(rs.getString("User_Type"));
					user1.setPrimaryEmail(rs.getString("Primary_Email"));
					user1.setPrimaryMobileNo(rs.getString("Primary_Mobile_No"));
					user1.setAlternateEmail(rs.getString("Alternate_Email"));
					user1.setAlternateMobileNo(rs.getString("Alternate_Mobile_No"));
					user1.setCountry(rs.getString("Country"));
					user1.setState(rs.getString("State"));
					user1.setCity(rs.getString("City"));
					user1.setAddress(rs.getString("Address"));
					user1.setZipcode(rs.getInt("Zipcode"));
					user1.setIdentityNumber(rs.getString("Identity_Number"));
					user1.setImage(rs.getString("Image"));
					imageList.add(images);
					user1.setImages(imageList);
					return user1;
				}).get(0);

		return user;
	}

	@Override
	public List<User> getusers() throws RDPException {
		List<User> userList=null;
		String query=null;
		Object[] params=null;
		
		query=environment.getProperty("USERS_SELECT");
		
		userList=jdbcTemplate.query(query,this::matchRows,params);
		
		return userList;

	}

	@Override
	public Integer deleteuser(Integer userId) throws RDPException {
		Integer result = 0;

		jdbcTemplate.update(environment.getProperty("DELETE_CONSULTANCY_BY_USERID"), new Object[] { userId });
		jdbcTemplate.update(environment.getProperty("DELETE_CONTRACTORS_BY_USERID"), new Object[] { userId });
		jdbcTemplate.update(environment.getProperty("DELETE_WORKPACKAGE_BY_USERID"), new Object[] { userId });
		result = jdbcTemplate.update(environment.getProperty("DELETE_USER_BY_ID"), new Object[] { userId });

		return result;
	}

	
	
	/**
	 * Mehtod for increase readability to match queries
	 * @throws SQLException 
	 * 
	 */
	
	private User matchRows(ResultSet rs,int rowNumber) throws SQLException {
		User user1=new User();
		Images images =new Images();
		List<Images> imageList=new ArrayList<>();
		user1.setUserId(rs.getInt("User_Id"));
		user1.setUsername(rs.getString("Username"));
		user1.setFullName(rs.getString("Fullname"));
		user1.setPassword(rs.getString("Password"));
		user1.setRoleId(rs.getInt("Role_Id"));
		user1.setRoleName(rs.getString("Role_Name"));
		user1.setDob(rs.getString("Dob"));
		user1.setGender(rs.getString("Gender"));
		user1.setUserType(rs.getString("User_Type"));
		user1.setPrimaryEmail(rs.getString("Primary_Email"));
		user1.setPrimaryMobileNo(rs.getString("Primary_Mobile_No"));
		user1.setAlternateEmail(rs.getString("Alternate_Email"));
		user1.setAlternateMobileNo(rs.getString("Alternate_Mobile_No"));
		user1.setCountry(rs.getString("Country"));
		user1.setState(rs.getString("State"));
		user1.setCity(rs.getString("City"));
		user1.setAddress(rs.getString("Address"));
		user1.setZipcode(rs.getInt("Zipcode"));
		user1.setIdentityNumber(rs.getString("Identity_Number"));
	//	user1.setImage(rs.getString("Image"));
		imageList.add(images);
		user1.setImages(imageList);
		return user1;	
	}

	@Override
	public User getuserbyusernamepass(String username, String password) {
		String query=null;
		Object[] params=null;
		User user=new User();
		params=new Object[]{username,password};

		query=environment.getProperty("USERS_SELECT_UNAME_PASS");

			
			//query+=" where username=? and password=?";
		
			
		user=jdbcTemplate.query(query,(rs,rowNum)->{
				User user1=new User();
				user1.setUserId(rs.getInt("User_Id"));
				user1.setUsername(rs.getString("Username"));
				user1.setFullName(rs.getString("Fullname"));
				user1.setPassword(rs.getString("Password"));
				user1.setRoleId(rs.getInt("Role_Id"));
				user1.setRoleName(rs.getString("Role_Name"));
				user1.setDob(rs.getString("Dob"));
				user1.setGender(rs.getString("Gender"));
				user1.setUserType(rs.getString("User_Type"));
				user1.setPrimaryEmail(rs.getString("Primary_Email"));
				user1.setPrimaryMobileNo(rs.getString("Primary_Mobile_No"));
				user1.setAlternateEmail(rs.getString("Alternate_Email"));
				user1.setAlternateMobileNo(rs.getString("Alternate_Mobile_No"));
				user1.setCountry(rs.getString("Country"));
				user1.setState(rs.getString("State"));
				user1.setCity(rs.getString("City"));
				user1.setAddress(rs.getString("Address"));
				user1.setZipcode(rs.getInt("Zipcode"));
				user1.setIdentityNumber(rs.getString("Identity_Number"));
				
				
				return user1;	
			},params).get(0);
		
		
		
	
		return user;
	}


	@Override
	public Integer updateUserPassword(User user) throws RDPException {
		String query = null;
		Integer result = 0;
		query = "update user u set u.Password='" + user.getPassword() + "'";
		if (user.getPrimaryMobileNo() != null) {
			query = query + " where u.Primary_Mobile_No=" + user.getPrimaryMobileNo() + "";
		} else if (user.getPrimaryEmail() != null) {
			query = query + " where u.Primary_Email='" + user.getPrimaryEmail() + "'";
		} else {
			return 0;
		}
		result = jdbcTemplate.update(query);
		return result;
	}

	@Override
	public List<Integer> validateOtp(User user) throws RDPException {
		List<Integer> userIdList = null;
		String query = null;

		query = environment.getProperty("VALIDATE_USERID_OTP");
		userIdList = jdbcTemplate.queryForList(query, Integer.class, user.getPrimaryMobileNo(), user.getOtp());
		return userIdList;
	}



}
