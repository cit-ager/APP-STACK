package com.rdp.web.resources;

import java.net.URISyntaxException;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rdp.domain.ResponseData;
import com.rdp.domain.SubFeatures;
import com.rdp.exception.RDPException;
import com.rdp.rest.response.SuccessResponse;
import com.rdp.security.utils.AuthTokenStore;
import com.rdp.security.utils.AuthorizationToken;
import com.rdp.services.SubFeatureService;
import com.rdp.utils.RDPConfig;

@RestController
@RequestMapping("/subfeature")
public class SubFeatureResource {

	private SuccessResponse<SubFeatures> successResponse;

	private ResponseData<SubFeatures> responseData;
	Logger logger = LoggerFactory.getLogger(SubFeatureResource.class);
	@Autowired
	private AuthTokenStore authTokenStore;

	@Autowired
	private SubFeatureService subfeatureService;

	@RequestMapping(value = "/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<SubFeatures>> getCategories(@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken) throws URISyntaxException {
		List<SubFeatures> subfeatureList = null;
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				subfeatureList = subfeatureService.getSubFeatures();
				
				if (subfeatureList.isEmpty()) {
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.OK.value());
					responseData.setMessage("No Records found");
					
				} else {
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.OK.value());
					responseData.setObjects(subfeatureList);
				}
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
			

		} catch (RDPException e) {
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());

		} catch (Exception e) {
			successResponse = new SuccessResponse<>();
			responseData = new ResponseData<>();
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			responseData.setMessage("No Records found");
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<SubFeatures>>(successResponse, HttpStatus.OK);

	}

	
}
