package com.rdp.services;

import java.util.List;

import com.rdp.domain.Feature;
import com.rdp.exception.RDPException;

public interface FeatureService {
	
public Integer saveFeature(Feature feature)throws RDPException;
	
	public Integer updateFeature(Feature feature)throws RDPException;
	
	public Feature getFeatureById(Integer featureId)throws RDPException;
	
	public Integer deleteFeature(Integer featureId)throws RDPException;
	
	public List<Feature> getFeatures()throws RDPException;

	


}
