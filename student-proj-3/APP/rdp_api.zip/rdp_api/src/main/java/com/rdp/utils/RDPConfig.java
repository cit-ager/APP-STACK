package com.rdp.utils;

public class RDPConfig {
	public static final String AUTH_TOKEN = "Auth_Token";
	public static final String ORG_ID="OrganizationId";
	public static final String tokenExpTimeInSecs = "172800";
	public static final String SNAG_IMAGE_PATH = "G:\\cucumber\\feature\\snag\\";
	public static final String SNAG_HISTORY_IMAGE_PATH = "G:\\cucumber\\feature\\snag_history\\";
	public static final String WORK_PACKAGE_IMAGE_PATH = "G:\\cucumber\\feature\\work_package\\";
	public static final String WORK_ITEM_IMAGE_PATH = "G:\\cucumber\\feature\\work_item\\";
	public static final String USER_IMAGE_PATH = "G:\\cucumber\\feature\\user\\";

	// User Org Level Types
	public static final String ORG_LEVEL_TYPE="Orgnization";
	public static final String BUU_LEVEL_TYPE="BusinessUnit";
	public static final String PT_LEVEL_TYPE="ProjectType";
	public static final String PS_LEVEL_TYPE="ProjectSite";
	public static final String PP_LEVEL_TYPE="ProjectPhase";
	public static final String BT_LEVEL_TYPE="BuildingType";
	public static final String BF_LEVEL_TYPE="BuildingFloor";
	public static final String BDU_LEVEL_TYPE="BuildingUnit";
	public static final String BDSU_LEVEL_TYPE="BuildingSubUnit";
}
