package com.rdp.domain;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Feature implements Serializable {

	private static final long serialVersionUID = 6209073992872680225L;
	private Integer featureId;
	private String featureName;
	private String featureDesc;
	private Integer subFeatureId;
	private String subFeatureName;
	private List<SubFeatures> subFeatures;

	private ErrorResp errorResponse;

	public ErrorResp getErrorResponse() {
		return errorResponse;
	}

	public void setErrorResponse(ErrorResp errorResponse) {
		this.errorResponse = errorResponse;
	}

	public Integer getFeatureId() {
		return featureId;
	}

	public void setFeatureId(Integer featureId) {
		this.featureId = featureId;
	}

	public String getFeatureName() {
		return featureName;
	}

	public void setFeatureName(String featureName) {
		this.featureName = featureName;
	}

	public String getFeatureDesc() {
		return featureDesc;
	}

	public void setFeatureDesc(String featureDesc) {
		this.featureDesc = featureDesc;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public List<SubFeatures> getSubFeatures() {
		return subFeatures;
	}

	public void setSubFeatures(List<SubFeatures> subFeatures) {
		this.subFeatures = subFeatures;
	}


	public Integer getSubFeatureId() {
		return subFeatureId;
	}

	public void setSubFeatureId(Integer subFeatureId) {
		this.subFeatureId = subFeatureId;
	}

	public String getSubFeatureName() {
		return subFeatureName;
	}

	public void setSubFeatureName(String subFeatureName) {
		this.subFeatureName = subFeatureName;
	}
	
	

}
