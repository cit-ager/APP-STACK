package com.rdp.dao;

import java.util.List;

import com.rdp.domain.User;
import com.rdp.exception.RDPException;


public interface UserDAO {

	public Object[] validateLogin(String username, String password) throws Exception;

	public Integer saveuser(User user) throws RDPException;

	

	public Integer updateuser(User user) throws RDPException;

	public User getuserById(Integer userId) throws RDPException;

	public List<User> getusers() throws RDPException;

	public Integer deleteuser(Integer userId) throws RDPException;

	public User getuserbyusernamepass(String username, String password) throws RDPException;

	public Integer updateUserPassword(User user) throws RDPException ;

	public List<Integer> validateOtp(User user) throws RDPException;
}
