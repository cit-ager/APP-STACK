package com.rdp.security.utils;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

import com.rdp.domain.User;




@XmlRootElement
public class AuthorizationToken implements Serializable {

	
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unused")
	private final static Integer DEFAULT_TTL = (60 * 60 * 24 * 30); // 30days

	private String token;

	private Date timeCreated;

	private Date expirationDate;

	private Date lastAccessedDate;

	private Integer ttl;

	private User user;

	public AuthorizationToken(User user, String token) {
		this.user = user;
		this.timeCreated = new Date();
		this.lastAccessedDate = new Date();
		this.token=token;
	}

	public AuthorizationToken(String token, User userDTO, Integer timeToLiveInSeconds) {
		this.token=token;
		this.user = userDTO;
		this.timeCreated = new Date();
		this.lastAccessedDate = new Date();
		this.expirationDate = new Date(System.currentTimeMillis()
				+ (timeToLiveInSeconds * 100000L));
		this.ttl = timeToLiveInSeconds;
	}
	

	public void resetExpirationDate() {
		this.lastAccessedDate = new Date();
		this.expirationDate = new Date(System.currentTimeMillis()
				+ (ttl * 1000000L));

	}

	public Date getLastAccessedDate() {
		return lastAccessedDate;
	}

	public void setLastAccessedDate(Date lastAccessedDate) {
		this.lastAccessedDate = lastAccessedDate;
	}

	public boolean hasExpired() {
		return this.expirationDate != null
				&& this.expirationDate.before(new Date());
	}

	public String getToken() {
		return token;
	}

	

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Date getTimeCreated() {
		return timeCreated;
	}

	@Override
	public String toString() {
		return "AuthorizationToken [token=" + token + ", timeCreated="
				+ timeCreated + ", expirationDate=" + expirationDate
				+ ", lastAccessedDate=" + lastAccessedDate + ", ttl=" + ttl
				+ ", UserDTO=" + user + "]";
	}

}
