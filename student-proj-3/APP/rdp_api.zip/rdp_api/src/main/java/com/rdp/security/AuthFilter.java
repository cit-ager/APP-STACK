package com.rdp.security;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.rdp.security.utils.AuthTokenStore;
import com.rdp.security.utils.TokenValidation;
import com.rdp.utils.RDPConfig;

@Component
public class AuthFilter implements Filter {

	private final String tokenHeader=RDPConfig.AUTH_TOKEN;
	
	@Autowired
    private TokenValidation tokenValidation;
	
	@Autowired
	private AuthTokenStore authTokenStore;
	
	@Override
	public void destroy() {
		authTokenStore.removeAllTokens();
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain arg2)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res; 
		response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "DELETE, HEAD, GET, POST, PUT, OPTIONS");
        response.setHeader("Access-Control-Max-Age", "3600");
        response.setHeader("Access-Control-Allow-Headers", "Auth_Token, Content-Type, Accept,x-requested-with, filter,BuildingUnitId,BuildingTypeId,BusinessUnitId, ProjectPhaseId, BuildingFloorId, OrganizationId, CategoryId, ProjectSiteId, ProjectTypeId,SuperOrganizationId");
        try {
			String url = request.getRequestURL().toString();
			String authToken = request.getHeader(this.tokenHeader);
			if(!request.getMethod().equals("OPTIONS")){
				if(url!=null 
						&& (!url.contains("validate-login")
					    && !url.contains("logout")
						&& !url.contains("unauthorized") 
						&& !url.contains("report") 
						&& !url.contains("category") 
						&& !url.contains("organization") 
						&& !url.contains("buildingsubunit") 
						&& !url.contains("buildingunit") 
						&& !url.contains("projectphase") 
						&& !url.contains("projecttype") 
						&& !url.contains("buildingfloor")
						&& !url.contains("buildingtype")
						&& !url.contains("businessunit")
						&& !url.contains("projectsite"))
						&& !url.contains("superorganization") 
						&& !url.contains("snags") 
						&& !url.contains("trade")
						&& !url.contains("tools") 
						&& !url.contains("user")
						&& !url.contains("workpackage")
						&& !url.contains("contractor")
						&& !url.contains("consultancy")
						&& !url.contains("workitem")
						&& !url.contains("role")
						&& !url.contains("feature")
						&& !url.contains("subfeature")
						&& !url.contains("feature2")
						&& !url.contains("tmp")
						&& !url.contains("snag")
						&& !url.contains("snag_history")
						&& !url.contains("work_item")
						&& !url.contains("projectLocation")
						&& !url.contains("test")
						&& !url.contains("test")
						&& !url.contains("getpdfreport")
						&&(!url.contains("shapoorji"))
						&& !url.contains("work_package")){
				    if (authToken == null || !tokenValidation.validateToken(authToken)) {
				    	response.sendRedirect("/unauthorized");
				    }
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
        arg2.doFilter(req, res);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		
		
	}

}
