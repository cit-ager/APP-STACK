package com.rdp.rest.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.rdp.domain.ResponseData;

/**
 * @author mlt
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SuccessResponse<T> {

	private int httpStatus;
	//private String message;
	private boolean status;
	private ResponseData<T> data;

	public SuccessResponse() {
		super();
	}

	public int getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(int httpStatus) {
		this.httpStatus = httpStatus;
	}
	
	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public ResponseData<T> getData() {
		return data;
	}

	public void setData(ResponseData<T> data) {
		this.data = data;
	}

}
