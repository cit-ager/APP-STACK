package com.rdp.web.resources;

import java.net.URISyntaxException;
import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rdp.domain.Feature;
import com.rdp.domain.ResponseData;
import com.rdp.domain.User;
import com.rdp.exception.RDPException;
import com.rdp.rest.response.SuccessResponse;
import com.rdp.security.utils.AuthTokenStore;
import com.rdp.security.utils.AuthorizationToken;
import com.rdp.services.RoleService;
import com.rdp.services.UserService;
import com.rdp.utils.RDPConfig;


@RestController
@RequestMapping("/user")
public class UserResource {

	private SuccessResponse<User> successResponse;

	private ResponseData<User> responseData;
	Logger logger = LoggerFactory.getLogger(UserResource.class);

	@Autowired
	private UserService userService;

	@Autowired
	private RoleService roleService;
	@Autowired
	private Environment environment;

	@Autowired
	private AuthTokenStore authTokenStore;

	@RequestMapping(value = "/validate-login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<User>> validateLogin(@Valid @RequestBody User user)
			throws RDPException {
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();

		try {

			user = userService.validateLogin(user);
			List<Feature> featureList = roleService.getFeatures(user.getRoleId());
			successResponse.setStatus(Boolean.TRUE);
			successResponse.setHttpStatus(HttpStatus.OK.value());
			user.setFeatures(featureList);
			responseData.setObject(user);
			successResponse.setData(responseData);

			logger.info("user has logged in with id {}", user.getUserId());

		} catch (Exception e) {
			throw new RDPException(HttpStatus.BAD_REQUEST.value(), "Unable to validate your authentication");

		}
		return new ResponseEntity<SuccessResponse<User>>(successResponse, HttpStatus.OK);
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SuccessResponse> logout(@RequestHeader(value = RDPConfig.AUTH_TOKEN) String authToken)
			throws RDPException {

		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();

		try {
			Integer userId=authTokenStore.retrieveToken(authToken).getUser().getUserId();
			authTokenStore.removeToken(authToken);

			successResponse.setHttpStatus(HttpStatus.OK.value());
			responseData.setMessage("Logout Successfully");
			successResponse.setData(responseData);

			logger.info("user has logged Out with id {}", userId);

		} catch (Exception e) {
			throw new RDPException(HttpStatus.BAD_REQUEST.value(), "Failed to logout");
		}

		return new ResponseEntity<SuccessResponse>(successResponse, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.POST, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<User>> saveUser(@RequestBody User user, HttpServletRequest request,
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		Integer count = 0;

		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				user.setCreatedBy(auth.getUser().getUserId());
				String realPath = environment.getProperty("realpath");
				String resultPath = environment.getProperty("resultpath");

				count = userService.saveUser(user, resultPath, realPath);

				if (count != null && count > 0) {

					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.CREATED.value());
					responseData.setMessage("user details Saved Successfully");
				} else {
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.CONFLICT.value());
					responseData.setMessage("user details failed to save");
				
				}
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
			
		} catch (RDPException e) {

			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());

		} catch (Exception e) {

			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			if (e.getMessage().contains("Name_UNIQUE")) {
				responseData.setMessage("user details already exists");
			} else {
				responseData.setMessage("Failed to Save user details");
			}
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<User>>(successResponse, HttpStatus.CREATED);
	}

	
	@RequestMapping(value = "/{id}", 
			method = RequestMethod.GET, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<User>> getUserById(@PathVariable("id") Integer userId,
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		User users = null;
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				users = userService.getUserById(userId);
				responseData.setObject(users);
				successResponse.setStatus(Boolean.TRUE);
				successResponse.setHttpStatus(HttpStatus.OK.value());
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
			

		} catch (RDPException e) {
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());
			successResponse.setData(responseData);
		} catch (Exception e) {
			successResponse = new SuccessResponse<>();
			responseData = new ResponseData<>();
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			responseData.setMessage("No Records found with this id");
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<User>>(successResponse, HttpStatus.OK);
	}

	@RequestMapping(value = "/list", 
			method = RequestMethod.GET, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<User>> getusers(@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		List<User> usersList = null;
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();

		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				usersList = userService.getusers();

				if (usersList.isEmpty()) {
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.OK.value());
					responseData.setMessage("No Records found");

				} else {
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.OK.value());
					responseData.setObjects(usersList);
				}

			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
			
		} catch (RDPException e) {
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());

		} catch (Exception e) {
			successResponse = new SuccessResponse<>();
			responseData = new ResponseData<>();
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			responseData.setMessage("No Records found");
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<User>>(successResponse, HttpStatus.OK);

	}

	@RequestMapping(value = "/{id}", 
			method = RequestMethod.DELETE, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<User>> deleteUser(@PathVariable("id") Integer userId,
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		Integer count = 0;
		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				count = userService.deleteUser(userId);
				successResponse = new SuccessResponse<>();
				successResponse.setHttpStatus(HttpStatus.OK.value());
				successResponse.setStatus(Boolean.TRUE);

				if (count != null && count > 0) {
					responseData.setMessage("User deleted Successfully");
				} else {
					responseData.setMessage("No record found to delete with id :" + userId);
				}
				successResponse.setData(responseData);
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
			
		} catch (RDPException e) {
			successResponse.setData(responseData);
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());

			successResponse.setData(responseData);
		} catch (Exception e) {
			successResponse.setData(responseData);
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			responseData.setMessage("Failed to deleted the User");
			successResponse.setData(responseData);
		}
		return new ResponseEntity<SuccessResponse<User>>(successResponse, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<User>> updateUser(@RequestBody User user, HttpServletRequest request,
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		Integer count = 0;
		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				user.setUpdatedBy(auth.getUser().getUserId());
				String realPath = environment.getProperty("realpath");
				String resultPath = environment.getProperty("resultpath");

				count = userService.updateUser(user, resultPath, realPath);

				if (count != null && count > 0) {
					successResponse.setHttpStatus(HttpStatus.OK.value());
					successResponse.setStatus(Boolean.TRUE);
					responseData.setMessage("User Updated Successfully");
				}
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
			
		} catch (RDPException e) {

			successResponse.setHttpStatus(e.getErrorCode());
			successResponse.setStatus(Boolean.FALSE);
			responseData.setMessage(e.getErrorMessage());
		} catch (Exception e) {

			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			successResponse.setStatus(Boolean.FALSE);
			responseData.setMessage("Failed to update the User");
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<User>>(successResponse, HttpStatus.OK);
	}
}
