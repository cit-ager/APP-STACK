package com.rdp.services;

import java.util.List;

import com.rdp.domain.SubFeatures;
import com.rdp.exception.RDPException;

public interface SubFeatureService {
	

	public List<SubFeatures> getSubFeatures()throws RDPException;

}
