package com.rdp.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rdp.dao.FeatureDao;
import com.rdp.domain.Feature;
import com.rdp.exception.RDPException;
import com.rdp.services.FeatureService;


@Service
@Transactional
public class FeatureServiceImpl implements FeatureService {

	@Autowired
	private FeatureDao featureDao;

	@Override
	public Integer saveFeature(Feature feature) throws RDPException {
		Integer result = null;
		try {
			result = featureDao.saveFeature(feature);
			if (result == 0) {
				throw new RDPException(HttpStatus.OK.value(), "Feature Couldn't saved");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}
		return result;
	}

	@Override
	public Integer updateFeature(Feature feature) throws RDPException {
		Integer result = 0;

		try {
			result = featureDao.updateFeature(feature);
			/*
			 * Check for updation successfull or not
			 */
			if (result == 0) {
				throw new RDPException(HttpStatus.OK.value(), "Feature Couldn't updated");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}
		return result;
	}

	@Override
	public Feature getFeatureById(Integer featureId) throws RDPException {
		Feature feature = null;

		feature = featureDao.getFeatureById(featureId);

		return feature;

	}

	@Override
	public Integer deleteFeature(Integer featureId) throws RDPException {
		Integer result = 0;
		try {
			result = featureDao.deleteFeature(featureId);

			if (result == 0) {
				throw new RDPException(HttpStatus.OK.value(), "Feature Couldn't delete");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}

		return result;
	}

	@Override
	public List<Feature> getFeatures() throws RDPException {
		List<Feature> featureList = null;

		try {
			featureList = featureDao.getFeatures();
			/*
			 * Check if featurelist empty or not if empty throw some exception.
			 */
			if (featureList.isEmpty()) {
				throw new RDPException(HttpStatus.OK.value(), "Features Not Found");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}

		return featureList;
	}

}
