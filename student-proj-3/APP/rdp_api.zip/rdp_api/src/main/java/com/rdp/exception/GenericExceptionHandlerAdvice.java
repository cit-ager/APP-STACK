package com.rdp.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.rdp.domain.ResponseData;
import com.rdp.domain.User;
import com.rdp.rest.response.SuccessResponse;


@RestControllerAdvice
public class GenericExceptionHandlerAdvice {

	
	@ExceptionHandler(RDPException.class) 
	public ResponseEntity<SuccessResponse> handleRDPException(RDPException expected) {
		SuccessResponse successResponse=new SuccessResponse();
		//System.out.println("in controller advice");
		successResponse = new SuccessResponse();
		ResponseData<User> responseData = new ResponseData<>(); 
		successResponse.setHttpStatus(expected.getErrorCode());
		responseData.setMessage(expected.getErrorMessage());
		successResponse.setData(responseData);
        return new ResponseEntity<SuccessResponse>(successResponse,	HttpStatus.OK);

	}
}
