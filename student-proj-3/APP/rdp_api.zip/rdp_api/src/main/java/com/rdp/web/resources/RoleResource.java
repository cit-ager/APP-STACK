package com.rdp.web.resources;

import java.net.URISyntaxException;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rdp.domain.ResponseData;
import com.rdp.domain.Role;
import com.rdp.exception.RDPException;
import com.rdp.rest.response.SuccessResponse;
import com.rdp.security.utils.AuthTokenStore;
import com.rdp.security.utils.AuthorizationToken;
import com.rdp.services.RoleService;
import com.rdp.utils.RDPConfig;

@RestController
@RequestMapping("/role")
public class RoleResource {

	private SuccessResponse<Role> successResponse;

	private ResponseData<Role> responseData;

	Logger logger = LoggerFactory.getLogger(RoleResource.class);
	@Autowired
	private AuthTokenStore authTokenStore;

	@Autowired
	private RoleService roleService;

	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<Role>> saveRole(@RequestBody Role role,
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		Integer count = 0;

		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				count = roleService.saveRole(role);

				if (count != null && count > 0) {

					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.CREATED.value());
					responseData.setMessage("Role details Saved Successfully");

					logger.info("user with id {} saved Role with role id {}", auth.getUser().getCreatedBy(), count);

				} else {
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.CONFLICT.value());
					responseData.setMessage("Role details are failed to save");

				}
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
			
		} catch (RDPException e) {

			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());

		} catch (Exception e) {

			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			if (e.getMessage().contains("Name_UNIQUE")) {
				responseData.setMessage("role details already exists");
			} else {
				responseData.setMessage("Failed to Save role details ");
			}
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<Role>>(successResponse, HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<Role>> updateRole(@RequestBody Role role,
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		Integer count = 0;
		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				count = roleService.updateRole(role);

				if (count != null && count > 0) {
					successResponse.setHttpStatus(HttpStatus.OK.value());
					successResponse.setStatus(Boolean.TRUE);
					responseData.setMessage("role details Updated Successfully");

					logger.info("user with id {} updated Role with role id {}", auth.getUser().getCreatedBy(), role.getRoleId());

				} else {
					successResponse.setHttpStatus(HttpStatus.OK.value());
					successResponse.setStatus(Boolean.TRUE);
					responseData.setMessage("role details failed to Update");

				}
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
			
		} catch (RDPException e) {

			successResponse.setHttpStatus(e.getErrorCode());
			successResponse.setStatus(Boolean.FALSE);
			responseData.setMessage(e.getErrorMessage());
		} catch (Exception e) {

			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			successResponse.setStatus(Boolean.FALSE);
			responseData.setMessage("Failed to update the role details");
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<Role>>(successResponse, HttpStatus.OK);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<Role>> getRolebyId(@PathVariable("id") Integer roleId,
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		Role role = null;
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				role = roleService.getRoleById(roleId);
				if (role != null) {
					responseData.setObject(role);
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.OK.value());

				} else {
					responseData.setMessage("Role not found");
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.NOT_FOUND.value());

				}
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}	
		} catch (RDPException e) {
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());
			successResponse.setData(responseData);
		} catch (Exception e) {
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			responseData.setMessage("No Records found with this id");
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<Role>>(successResponse, HttpStatus.OK);
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<Role>> getCategories(
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		List<Role> roleList = null;
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		
		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				roleList = roleService.getRoles();

				if (roleList.isEmpty()) {
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.OK.value());
					responseData.setMessage("No Records found");

				} else {
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.OK.value());
					responseData.setObjects(roleList);
				}
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
		} catch (RDPException e) {
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());

		} catch (Exception e) {
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			responseData.setMessage("No Records found");
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<Role>>(successResponse, HttpStatus.OK);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<Role>> deleteRole(@PathVariable("id") Integer roleId,
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		Integer count = 0;
		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				count = roleService.deleteRole(roleId);

				successResponse.setHttpStatus(HttpStatus.OK.value());
				successResponse.setStatus(Boolean.TRUE);

				if (count != null && count > 0) {
					responseData.setMessage("role details deleted Successfully");
				} else {
					responseData.setMessage("No record found to delete with id :" + roleId);
				}
				successResponse.setData(responseData);
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
			
		} catch (RDPException e) {
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());

			successResponse.setData(responseData);
		} catch (Exception e) {
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			responseData.setMessage("Failed to deleted the Role details");
			successResponse.setData(responseData);
		}
		return new ResponseEntity<SuccessResponse<Role>>(successResponse, HttpStatus.OK);
	}
}
