package com.rdp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@ComponentScan("com")
@EnableTransactionManagement
@EnableScheduling
@PropertySource(value="classpath:queries.properties")

public class RDPApplication {
	
    public static void main(String[] args) {
        SpringApplication.run(RDPApplication.class, args);
    }
}