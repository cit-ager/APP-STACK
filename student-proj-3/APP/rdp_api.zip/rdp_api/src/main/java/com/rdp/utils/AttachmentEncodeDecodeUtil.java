package com.rdp.utils;

import org.apache.commons.codec.binary.Base64;

public class AttachmentEncodeDecodeUtil {
	

    public static String encodeImage(byte[] imageByteArray) {
        return Base64.encodeBase64String(imageByteArray);
    }
 
   
    public static byte[] decodeImage(String imageDataString) {
        return Base64.decodeBase64(imageDataString);
    }
}
