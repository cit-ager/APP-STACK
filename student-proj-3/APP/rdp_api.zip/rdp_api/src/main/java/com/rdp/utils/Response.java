/*
 * @(#)Response.java		1.0
 * 
 */
package com.rdp.utils;

/**
 * This class is representing the status code.
 * @author mlt
 *
 */
public class Response {
	
	private int status;
	private String message;
	
	/**
	 * Default constructor for default error message.
	 */
	public Response() {
		status=500;
		message="Some thing went wrong";
	}
	/**
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(int status) {
		this.status = status;
	}
	/**
	 * @return the msg
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param msg the msg to set
	 */
	public void setMessage(String msg) {
		this.message = msg;
	}
}
