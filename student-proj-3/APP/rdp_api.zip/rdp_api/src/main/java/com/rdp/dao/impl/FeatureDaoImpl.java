package com.rdp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.rdp.dao.FeatureDao;
import com.rdp.domain.Feature;
import com.rdp.exception.RDPException;

@Repository
@Transactional
public class FeatureDaoImpl implements FeatureDao {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private Environment environment;

	@Override
	public Integer saveFeature(Feature feature) throws RDPException {
		String query=null;
		Object[] params=null;
		Integer result=0;
		
		params=new Object[]{feature.getFeatureName(),feature.getFeatureDesc()};
		query=environment.getProperty("INSERT_FEATURE");
		result=jdbcTemplate.update(query, params);
				
		return result;
	}

	@Override
	public Integer updateFeature(Feature feature) throws RDPException {
		String query=null;
		Object[] params=null;
		Integer result=0;
		
		params=new Object[]{feature.getFeatureName(),feature.getFeatureDesc(),feature.getFeatureId()};
		query=environment.getProperty("UPDATE_FEATURE");
		result=jdbcTemplate.update(query, params);			
		
		return result;
	}

	@Override
	public Feature getFeatureById(Integer featureId) throws RDPException {
		String query=null;
		Object[] params=null;
		Feature feature=null;
		
		params=new Object[]{featureId};
		query=environment.getProperty("SELECT_FEATURE_BY_ID");
		//execute query
		
		feature=jdbcTemplate.query(query,params,this::matchRows).get(0);
		
		return feature;

	}

	@Override
	public Integer deleteFeature(Integer featureId) throws RDPException {
		String query=null;
		Object[] params=null;
		Integer result=0;
		
		params=new Object[]{featureId};
		query=environment.getProperty("DELETE_FEATURE");
		result=jdbcTemplate.update(query, params);			
		
		return result;
		
	}

	@Override
	public List<Feature> getFeatures() throws RDPException {
		String query=null;
		List<Feature> feature=null;
		
		
		query=environment.getProperty("SELECT_FEATURE");
		//execute query
		
		feature=jdbcTemplate.query(query,this::matchRows);
		
		return feature;
	}
	
	
	private Feature matchRows(ResultSet rs,int rowNumber) throws SQLException {
		Feature f=new Feature();
		f.setFeatureId(rs.getInt("Feature_Id"));
		f.setFeatureName(rs.getString("Feature_Name"));
		f.setFeatureDesc(rs.getString("Description"));
		
		return f;
	}
	
	

}
